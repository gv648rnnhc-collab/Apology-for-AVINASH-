APOLOGY WEBSITE
Open index.html to start.

Every step is a separate HTML page:
index.html -> message1.html -> message2.html -> message3.html -> note.html -> forgive.html -> yes.html/time.html

To make it a public free link, upload the whole folder to a static website host such as Netlify or GitHub Pages. Keep all files together.
